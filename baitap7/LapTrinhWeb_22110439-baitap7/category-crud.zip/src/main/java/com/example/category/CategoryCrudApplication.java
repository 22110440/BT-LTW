package com.example.category;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryCrudApplication.class, args);
	}

}
